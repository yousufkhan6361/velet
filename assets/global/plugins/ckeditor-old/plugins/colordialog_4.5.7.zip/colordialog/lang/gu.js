/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'gu', {
	clear: 'સાફ કરવું',
	highlight: 'હાઈઈટ',
	options: 'રંગના વિકલ્પ',
	selected: 'પસંદ કરેલો રંગ',
	title: 'રંગ પસંદ કરો'
} );
