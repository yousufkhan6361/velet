/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ca', {
	clear: 'Neteja',
	highlight: 'Destacat',
	options: 'Opcions del color',
	selected: 'Color Seleccionat',
	title: 'Seleccioni el color'
} );
